const postReducer = (state = [], action) => {
  console.log('postReducer state', state)
  console.log("..Action = ",action)
  switch (action.type) {
    case "ADD_POST":
      return state.concat([action.data]);
    case "DELETE_POST":
      console.log('delete post', state)
      return state.filter(post => post.id !== action.id);
    case "EDIT_POST":
        console.log('edit post',state)
      return state.map(post =>
        post.id === action.id ? { ...post, editing: !post.editing } : post
      );
    case "UPDATE":
      console.log('update',state)
      return state.map(post => {
        if (post.id === action.id) {
          return {
            ...post,
            title: action.data.newTitle,
            message: action.data.newMessage,
            editing: !post.editing
          };
        } else return post;
      });
    default:
      return state;
  }
};
export default postReducer;
